public enum RoomType {

    SINGLE,
    DOUBLE,
    SUITE
    
}
