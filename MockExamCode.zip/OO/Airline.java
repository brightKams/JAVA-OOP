public enum Airline {
    BrittishAirways,
    KLM,
    Lufthansa,
    Swiss,
    AirFrance,
    Ryanair,
    Austrian,
    Brussels   
}
