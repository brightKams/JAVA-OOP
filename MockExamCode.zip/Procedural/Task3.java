public class Task3 {

    public static void main(String[] args) {

        final double  number1 = 3.141592;
        double number2 = number1;

        System.out.println("Number1: " + number1 + " Number 2: " + number2);

        System.out.printf("Number1: %.2f -  Number2:  %.2f \n", number1, number2);


    }
    
}
