public class Task7 {

    public static void main(String[] args) {
        final double radius = 4.0;

        double area = Math.PI * radius * radius;

        System.out.printf("\nCircle Radius: %.2f Area:  %.2f \n", radius,  area);

    }
    
}
