public class Parent extends Person{
    public Parent(String name, Gender gender){
        super(name, gender);

    }  
}
