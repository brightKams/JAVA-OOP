public class Child extends Person{

    public Child(String name, Gender gender){
        super(name, gender);

    } 
}
