package OOP;
public enum Airline {
    BA,
    KLM,
    SWISS;
}
