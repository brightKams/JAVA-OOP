package OOP;
public enum RoomType {
    SINGLE, 
    DOUBLE, 
    SUIT;
}
