import java.util.ArrayList;

public class AllBookings extends Booking {

    ArrayList<Booking> bookings ;
    public AllBookings(String bookingDate, String customerName, String bookingNumber) {
        super(bookingDate, customerName, bookingNumber);
        
    }
    
    public String getdetails() {
       String  st = " ";
        return st;
    }
    
}
