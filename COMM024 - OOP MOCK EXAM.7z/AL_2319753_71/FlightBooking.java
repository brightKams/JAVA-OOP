public class FlightBooking extends Booking {
   
    public Airline airline;
    public String lightNumber;
    public double price;

    public FlightBooking(String bookingDate, String customerName, String bookingNumber, Airline airline, String lightNumber, double price) {
        super(bookingDate, customerName, bookingNumber);

    }

    // GETTERS 
     public Airline getAirline() {
        return airline;
    }
    public void setAirline(Airline airline) {
        this.airline = airline;
    }
    public String getLightNumber() {
        return lightNumber;
    }

    //  END OF GETTERS

    // SETTERS
    public void setLightNumber(String lightNumber) {
        this.lightNumber = lightNumber;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    // END OF SETTERS

    public String getdetails() {
        String st = "Customer Name: " + this.customerName + "\nBooking Number: " + this.bookingNumber
                + "\nBooking Date: " + this.bookingDate;

        return st;
    }

    public String toString() {
        return getdetails();
    }

}
