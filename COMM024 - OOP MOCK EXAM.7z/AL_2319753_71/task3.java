public class task3 {
    

    public static void main(String[] args) {
            final double number1 = 3.141592;
            double number2 = 3.1451592;


            System.out.println("Number1: " + number1 + "Number: " + number2);
            System.out.printf("Number1: %.2f " + "Number2: %.2f", number1, number2);


    }
}
