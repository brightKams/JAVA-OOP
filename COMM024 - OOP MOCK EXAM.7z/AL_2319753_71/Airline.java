public enum Airline {
    BA,
    KLM,
    SWISS;

    public static void main(String[] args) {

    }

}
