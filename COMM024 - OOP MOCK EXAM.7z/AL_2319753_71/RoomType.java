public enum RoomType {
    SINGLE, DOUBLE, SUIT;
}
