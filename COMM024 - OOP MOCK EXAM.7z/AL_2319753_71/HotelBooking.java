public class HotelBooking extends Booking {

    public RoomType roomType;
    public int roomNumber;
    public int numberNights;
    public double price;

    public HotelBooking(String bookingDate, String customerName, String bookingNumber, RoomType roomType,
            int roomNumber, int numberNights) {
        super(bookingDate, customerName, bookingNumber);

    }

    // GETTERS
    public String getBookingdate() {
        return this.bookingDate;
    }

    public String getCustomerName() {
        return this.customerName;
    }

    public String getookingNumber() {
        return this.bookingDate;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getNumberNights() {
        return numberNights;
    }

    public double getPrice() {
        return price;
    }

    // END OF GETTERS

    // SETTERS
    public void getBookingdate(String BookingDate) {
        this.bookingDate = BookingDate;
    }

    public void getCustomerName(String CustomerName) {
        this.customerName = CustomerName;
    }

    public void getookingNumber(String BookingNumber) {
        this.bookingDate = BookingNumber;
    }

    public void setRoomType(RoomType roomType) {
        this.roomType = roomType;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setNumberNights(int numberNights) {
        this.numberNights = numberNights;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // END OF SETTERS

    public String getdetails() {
        String st = "Customer Name: " + this.customerName + "\nBooking Number: " + this.bookingNumber
                + "\nBooking Date: " + this.bookingDate;

        return st;
    }

    public String toString() {
        return getdetails();
    }

}
